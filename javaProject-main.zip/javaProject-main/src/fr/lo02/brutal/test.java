package fr.lo02.brutal;

public class test {
	public static void main(String[] args) {
		System.out.println("testlesgos");
	}
}
