package fr.lo02.brutal;

import java.util.ArrayList;
import java.util.List;

public class Player {
	
    private String pseudo,filiere;
    private int creditECTS;
    private boolean gagnant;
    private List<Combattant> combattant = new ArrayList<Combattant> ();
    public List<Combattant> reserviste = new ArrayList<Combattant> ();
    
    Player(String pseudo, String filiere){
    	this.pseudo = pseudo;
    	this.filiere = filiere;
    	this.creditECTS = 400;
    }

    String getPseudo() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.pseudo;
    }

    void setPseudo(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.pseudo = value;
    }

    int getCreditECTS() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.creditECTS;
    }

    void setCreditECTS(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.creditECTS = value;
    }

    String getFiliere() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.filiere;
    }

    void setFiliere(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.filiere = value;
    }

    boolean isGagnant() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.gagnant;
    }

    void setGagnant(boolean value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.gagnant = value;
    }

    List<Combattant> getCombattant() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.combattant;
    }

    void setCombattant(List<Combattant> value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.combattant = value;
    }

    List<Combattant> getReserviste() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.reserviste;
    }

    void setReserviste(List<Combattant> value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.reserviste = value;
    }
    

}
