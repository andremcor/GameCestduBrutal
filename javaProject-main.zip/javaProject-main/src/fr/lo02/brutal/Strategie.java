package fr.lo02.brutal;

public interface Strategie {
	public void attack(Combattant f);
	public void heal(Combattant f);
	public void randomAction(Combattant e, Combattant a);
}
