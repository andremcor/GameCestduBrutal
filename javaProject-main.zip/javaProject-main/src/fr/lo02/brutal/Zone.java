package fr.lo02.brutal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Zone {
	
    private String name;
    private Player winner;
    public List<Combattant> combattantP1 = new ArrayList<Combattant> ();
    public List<Combattant> combattantP2 = new ArrayList<Combattant> ();

    Zone(String n) {
		this.name = n;
		this.winner = null;
	}
	
	public String getName() { return this.name; }
	public Player getWinner() { return this.winner; }

    List<Combattant> getCombattantP1() { return this.combattantP1;}

    void setCombattantP1(List<Combattant> value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.combattantP1 = value;
    }
    
    List<Combattant> getCombattantP2() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.combattantP2;
    }

    void setCombattantP2(List<Combattant> value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.combattantP2 = value;
    }
    
    
    void combat() {
    	Collections.sort(this.combattantP1);
    	Collections.sort(this.combattantP2);
    	Combattant.affComb(this.combattantP1);
    	System.out.println();
    	Combattant.affComb(this.combattantP2);
    	
    }

}
