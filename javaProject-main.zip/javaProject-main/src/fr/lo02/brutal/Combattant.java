package fr.lo02.brutal;

import java.util.Arrays;
import java.util.List;

public class Combattant implements Strategie, Comparable<Combattant>{
    
	private int dexterite;

    private int creditECTS;

    private int force;

    private int resistance;

    private int constitution;

    private int initiative;

    private Strategie strategie;

    private Role role;
    
    Combattant(int dex,int force, int res, int cons, int ini, String stra, Role r){
    	this.dexterite =dex;
    	this.force = force;
    	this.resistance=res;
    	this.constitution = cons;
    	this.initiative = ini;
    	this.role=r;
    	
    }


    Strategie getStrategie() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.strategie;
    }

    void setStrategie(Strategie value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.strategie = value;
    }

    Role getRole() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.role;
    }

    void setRole(Role value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.role = value;
    }
    
    int getDexterite() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.dexterite;
    }

    void setDexterite(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.dexterite = value;
    }

    int getCreditECTS() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.creditECTS;
    }

    void setCreditECTS(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.creditECTS = value;
    }

    int getForce() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.force;
    }

    void setForce(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.force = value;
    }

    int getResistance() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.resistance;
    }

    void setResistance(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.resistance = value;
    }

    int getConstitution() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.constitution;
    }

    void setConstitution(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.constitution = value;
    }

    int getInitiative() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.initiative;
    }

    void setInitiative(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.initiative = value;
    }
    
    public int[] getStats() {
		int stats[] = {this.dexterite,this.force,this.resistance,this.constitution,this.initiative};
		return stats;
	}
    
    static void affComb(List<Combattant> combattants) {
    	for (int i = 0; i < combattants.size(); i++) {
			System.out.print((i+1) + " : " + Arrays.toString(combattants.get(i).getStats()) + " / ");
			if (i==4 | i==9 | i==14) {
				System.out.println();
			}
		}
    	System.out.println();
    }
    
    
    /*
	 * This function allow to each player to generate their fighters randomly.
	 * Each fighter will have random statistics.
	 * The function takes as an input, the number of the combattant and the player associated.
	 * This function returns one combattant generated randomly.
	 */
     static Combattant generateRandomly(int nbCombattant, Player player) {
    	Role r;
		if(nbCombattant==0) {r=Role.maitreGobi;}
		else if(nbCombattant<5) {r=Role.elite;}
		else {r=Role.basique;}
		
    	int[] stats = r.getStats();
    	int random;
    	int max;
    	
    	for (int i = 0; i < stats.length; i++) {
    		max = Math.min(player.getCreditECTS(), 10-stats[i]);
			random= (int)(Math.random() * (max + 1));
			stats[i]+=random;
	    	player.setCreditECTS(player.getCreditECTS()-random);
		}
    	Combattant warrior = new Combattant(stats[0], stats[1], stats[2], 
    			stats[3], stats[4], "r", r);
    	return warrior;
    }
     
     
     /*
 	 * This function allow to each player to generate their fighters.
 	 * As an input, * The function takes, the number of the combattant and the player associated.
 	 * to each ability and the strategy of the fighter
 	 * Format: Str/Dex/Res/Con/Ini/Strat
 	 * This function returns one combattant.
 	 */
     static Combattant generate(int nbCombattant, Player player) {
    	 
    	 	String[] input;
    	 	Role r;
    	 	if(nbCombattant==0) {r=Role.maitreGobi;}
    	 	else if(nbCombattant<5) {r=Role.elite;}
    	 	else {r=Role.basique;}
    	 	int[] stats = r.getStats();
    	 	
			System.out.println(player.getCreditECTS() + "credit(s)° restant");
			System.out.println("Saisir Dex/For/Res/Cons/Ini/Stra : " + (nbCombattant+1)+"-"+r +" -> "+ Arrays.toString(stats));
			input=Utils.getCombInput("", stats, player.getCreditECTS());
			
			Combattant warrior = new Combattant(Integer.parseInt(input[0])+stats[0], 
					Integer.parseInt(input[1])+stats[1], Integer.parseInt(input[2])+stats[2], 
					Integer.parseInt(input[3])+stats[3], Integer.parseInt(input[4])+stats[4], 
					input[5], r);
			
	    	int sum=0;
	    	for (int i = 0; i < input.length-1; i++) {
				sum +=Integer.parseInt(input[i]);
			}
	    	player.setCreditECTS(player.getCreditECTS()-sum);
			
			
			System.out.println(""+(nbCombattant+1) + " : " + r +" -> "+ Arrays.toString(warrior.getStats()));
			return warrior;
     }


	@Override
	public void attack(Combattant f) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void heal(Combattant f) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void randomAction(Combattant e, Combattant a) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public int compareTo(Combattant o) {
		return o.getInitiative()-this.initiative;
	}

}
